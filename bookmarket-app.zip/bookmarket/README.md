# BookMarket (starter slice)
1. Create a Supabase project. SQL Editor: run `supabase/migrations/0001_init.sql`.
2. Auth > Providers: Email, enable "Confirm email"; set Site URL + redirect URLs.
3. `cp .env.example .env.local`, fill URL + anon key. `npm i && npm run dev`.
4. First admin: `update profiles set role='admin' where email='you@example.com';`
## Implemented (real DB/RPC calls)
Sign up/in/out/reset, home feed, paginated search, seller comparison, cart, order placement (server-side price/stock check).
## NOT built yet
Seller dashboard + sell flow, admin dashboard, messaging UI, reviews UI, wishlist, map, My Library, address form, order tracking UI.
## PENDING EXTERNAL INTEGRATION
Payment provider init + webhook Edge Function (call rpc `mark_payment_succeeded` with service role), payouts, signed ebook URLs, Google Books import, email/push.
## Limits
Escrow not implemented. Multi-seller orders share one status. Not yet acceptance-tested end to end.
