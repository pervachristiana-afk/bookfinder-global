"use client";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
export default function Cart() {
  const [items, setItems] = useState<any[]>([]); const [msg, setMsg] = useState("");
  const load = () => supabase.from("cart_items").select("id,quantity,listings(title,price,currency)").then(r => setItems(r.data ?? []));
  useEffect(() => { load(); }, []);
  const total = items.reduce((s, i) => s + i.quantity * i.listings.price, 0);
  async function qty(id: string, q: number) { await (q < 1 ? supabase.from("cart_items").delete().eq("id", id) : supabase.from("cart_items").update({ quantity: q }).eq("id", id)); load(); }
  async function checkout() {
    const { data: u } = await supabase.auth.getUser();
    const { data: addr } = await supabase.from("addresses").select("*").eq("user_id", u.user!.id).eq("is_default", true).maybeSingle();
    if (!addr) return setMsg("Add a default address first (addresses table).");
    const { data, error } = await supabase.rpc("place_order", { p_shipping: addr, p_delivery_fee: 0 });
    setMsg(error ? error.message : `Order ${data} created. PENDING EXTERNAL INTEGRATION: payment provider checkout + webhook.`); load();
  }
  return (<main><h1>Cart</h1>
    {items.map(i => <div key={i.id} className="card"><div style={{ flex: 1 }}><b>{i.listings.title}</b><div>{i.listings.currency} {i.listings.price}</div></div>
      <button style={{ width: 44 }} onClick={() => qty(i.id, i.quantity - 1)}>−</button><span>{i.quantity}</span><button style={{ width: 44 }} onClick={() => qty(i.id, i.quantity + 1)}>+</button></div>)}
    <h3>Subtotal: {total.toFixed(2)}</h3>{items.length > 0 && <button onClick={checkout}>Checkout</button>}<p>{msg}</p></main>);
}
