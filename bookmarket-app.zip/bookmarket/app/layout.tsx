import "./globals.css";
import Link from "next/link";
export const metadata = { title: "BookMarket", description: "Every Book. Every Seller. One Marketplace." };
export default function Root({ children }: { children: React.ReactNode }) {
  return (<html lang="en"><body>{children}
    <nav><Link href="/">Home</Link><Link href="/search">Search</Link><Link href="/cart">Cart</Link><Link href="/auth">Account</Link></nav>
  </body></html>);
}
