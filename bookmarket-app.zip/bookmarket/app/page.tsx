"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { supabase } from "@/lib/supabase";
export default function Home() {
  const [items, setItems] = useState<any[]>([]);
  useEffect(() => { supabase.rpc("search_listings", { p_sort: "newest", p_limit: 12 }).then(r => setItems(r.data ?? [])); }, []);
  return (<main>
    <h1>Find Your Next Book</h1><p className="muted">Buy and sell books from trusted sellers anywhere.</p>
    <form action="/search"><input name="q" placeholder="Search books, authors, ISBNs or stores..." /></form>
    <h2>New Arrivals</h2>
    {items.length === 0 && <p className="muted">No listings yet. Sellers add real listings via the database.</p>}
    {items.map(i => <Link key={i.listing_id} href={i.edition_id ? `/book/${i.edition_id}` : "/search"} className="card">
      <img src={i.cover_image_url ?? ""} alt="" /><div><b>{i.title}</b><div className="muted">{i.author}</div>{i.currency} {i.price} · {i.store_name}</div></Link>)}
  </main>);
}
