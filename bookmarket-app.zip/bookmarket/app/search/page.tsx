"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { supabase } from "@/lib/supabase";
const PAGE = 24;
export default function Search() {
  const [q, setQ] = useState(""); const [sort, setSort] = useState("relevance"); const [ebook, setEbook] = useState("");
  const [rows, setRows] = useState<any[]>([]); const [more, setMore] = useState(false);
  async function load(offset: number, replace: boolean) {
    const { data } = await supabase.rpc("search_listings", { q: q || null, p_sort: sort, p_ebook: ebook === "" ? null : ebook === "1", p_limit: PAGE, p_offset: offset });
    setRows(r => replace ? data ?? [] : [...r, ...(data ?? [])]); setMore((data?.length ?? 0) === PAGE);
  }
  useEffect(() => { const t = setTimeout(() => load(0, true), 300); return () => clearTimeout(t); }, [q, sort, ebook]);
  return (<main><h1>Search</h1>
    <input value={q} onChange={e => setQ(e.target.value)} placeholder="Title, author, ISBN, store..." />
    <select value={sort} onChange={e => setSort(e.target.value)}><option value="relevance">Relevance</option><option value="price_asc">Lowest price</option><option value="rating">Highest rating</option><option value="fastest">Fastest delivery</option><option value="newest">Newest</option></select>
    <select value={ebook} onChange={e => setEbook(e.target.value)}><option value="">Physical + Ebook</option><option value="0">Physical</option><option value="1">Ebook</option></select>
    {rows.map(i => <Link key={i.listing_id} href={i.edition_id ? `/book/${i.edition_id}` : "#"} className="card">
      <img src={i.cover_image_url ?? ""} alt="" /><div><b>{i.title}</b><div className="muted">{i.author} · {i.format} · {i.condition}</div>{i.currency} {i.price} · ⭐ {i.seller_rating} {i.seller_verified && "✓"} {i.store_name}</div></Link>)}
    {more && <button onClick={() => load(rows.length, false)}>Load more</button>}
  </main>);
}
