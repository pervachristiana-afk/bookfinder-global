"use client";
import { useEffect, useState, use } from "react";
import { supabase } from "@/lib/supabase";
export default function Book({ params }: { params: Promise<{ editionId: string }> }) {
  const { editionId } = use(params);
  const [offers, setOffers] = useState<any[]>([]); const [sort, setSort] = useState("best"); const [msg, setMsg] = useState("");
  useEffect(() => { supabase.rpc("compare_offers", { p_edition: editionId }).then(r => setOffers(r.data ?? [])); }, [editionId]);
  const sorted = [...offers].sort((a, b) => sort === "price" ? a.price - b.price : sort === "rating" ? b.seller_rating - a.seller_rating
    : sort === "fast" ? (a.delivery_days ?? 99) - (b.delivery_days ?? 99) : b.best_score - a.best_score);
  async function add(o: any) {
    const { data: u } = await supabase.auth.getUser(); if (!u.user) return setMsg("Please log in first.");
    const { data: cart } = await supabase.from("carts").select("id").eq("user_id", u.user.id).single();
    const { error } = await supabase.from("cart_items").upsert({ cart_id: cart!.id, listing_id: o.listing_id, quantity: 1, price_at_time: o.price }, { onConflict: "cart_id,listing_id" });
    setMsg(error ? error.message : "Added to cart (price is re-checked server-side at checkout).");
  }
  return (<main><h1>Compare sellers</h1>
    <select value={sort} onChange={e => setSort(e.target.value)}><option value="best">Best overall</option><option value="price">Lowest price</option><option value="rating">Highest rating</option><option value="fast">Fastest delivery</option></select>
    {sorted.map(o => <div key={o.listing_id} className="card"><div style={{ flex: 1 }}><b>{o.store_name}</b> {o.seller_verified && "✓ Verified"}
      <div>{o.currency} {o.price} · ⭐ {o.seller_rating}</div><div className="muted">{o.condition} · {o.delivery_days != null ? `Delivery: ${o.delivery_days} day(s)` : ""} {o.pickup_available && "· Pickup available"}</div></div>
      <button style={{ width: 120 }} onClick={() => add(o)}>Add</button></div>)}
    {offers.length === 0 && <p className="muted">No active offers for this edition.</p>}<p>{msg}</p></main>);
}
