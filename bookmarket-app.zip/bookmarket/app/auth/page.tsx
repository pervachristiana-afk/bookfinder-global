"use client";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
export default function Auth() {
  const [mode, setMode] = useState<"in" | "up">("in");
  const [f, setF] = useState({ email: "", password: "", full_name: "", phone: "", country: "", city: "", account_purpose: "buyer" });
  const [msg, setMsg] = useState(""); const [user, setUser] = useState<any>(null);
  useEffect(() => { supabase.auth.getUser().then(r => setUser(r.data.user)); }, []);
  const set = (k: string) => (e: any) => setF({ ...f, [k]: e.target.value });
  async function submit() {
    const { email, password, ...meta } = f;
    const r = mode === "up"
      ? await supabase.auth.signUp({ email, password, options: { data: meta, emailRedirectTo: location.origin } })
      : await supabase.auth.signInWithPassword({ email, password });
    setMsg(r.error ? r.error.message : mode === "up" ? "Check your email to verify your account." : "Signed in.");
    if (!r.error && mode === "in") setUser(r.data.user);
  }
  async function reset() { const r = await supabase.auth.resetPasswordForEmail(f.email, { redirectTo: location.origin }); setMsg(r.error?.message ?? "Reset email sent."); }
  if (user) return <main><h1>Account</h1><p>{user.email}</p><button onClick={async () => { await supabase.auth.signOut(); setUser(null); }}>Log out</button></main>;
  return (<main><h1>{mode === "in" ? "Log in" : "Create account"}</h1>
    {mode === "up" && <>
      <input placeholder="Full name" onChange={set("full_name")} /><input placeholder="Phone" onChange={set("phone")} />
      <input placeholder="Country" onChange={set("country")} /><input placeholder="City" onChange={set("city")} />
      <select onChange={set("account_purpose")}><option value="buyer">Buyer</option><option value="seller">Seller</option><option value="both">Both</option></select></>}
    <input type="email" placeholder="Email" onChange={set("email")} /><input type="password" placeholder="Password" onChange={set("password")} />
    <button onClick={submit}>{mode === "in" ? "Log in" : "Sign up"}</button>
    <p><a href="#" onClick={() => setMode(mode === "in" ? "up" : "in")}>{mode === "in" ? "New here? Sign up" : "Have an account? Log in"}</a> · <a href="#" onClick={reset}>Forgot password</a></p>
    <p>{msg}</p></main>);
}
