-- =====================================================================
-- BOOKMARKET — Supabase schema, RLS, storage, RPCs
-- Run in Supabase SQL Editor (or save as supabase/migrations/0001_init.sql)
-- Order: extensions > enums > tables > indexes > functions > triggers > RLS > storage
-- =====================================================================

create extension if not exists pg_trgm;
create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------
-- 1. ENUMS
-- ---------------------------------------------------------------------
create type user_role          as enum ('buyer','seller','both','admin');
create type verification_state as enum ('unverified','pending','verified','rejected','suspended');
create type book_type          as enum ('physical','ebook','both');
create type edition_format     as enum ('Paperback','Hardcover','Mass Market','Audiobook','Ebook','Other');
create type book_condition     as enum ('New','Like New','Good','Acceptable');
create type listing_status     as enum ('draft','pending_review','active','paused','sold_out','rejected','removed');
create type ebook_rights       as enum ('seller_owned','author_owned','publisher_authorized','public_domain','licensed');
create type order_status       as enum ('pending_payment','payment_successful','seller_processing','shipped',
                                        'out_for_delivery','delivered','buyer_confirmed','completed',
                                        'cancelled','refunded','disputed');
create type payment_status     as enum ('pending','successful','failed','refunded','partially_refunded');
create type payout_status      as enum ('pending','on_hold','processing','paid','failed');
create type dispute_status     as enum ('open','under_review','resolved_buyer','resolved_seller','closed');
create type report_status      as enum ('open','reviewing','actioned','dismissed');

-- ---------------------------------------------------------------------
-- 2. TABLES
-- ---------------------------------------------------------------------
create table categories (
  id                 uuid primary key default gen_random_uuid(),
  name               text not null,
  slug               text not null unique,
  description        text,
  image_url          text,
  parent_category_id uuid references categories(id) on delete set null,
  created_at         timestamptz not null default now()
);

create table profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  full_name   text not null default '',
  email       text,
  phone       text,
  country     text,
  city        text,
  avatar_url  text,
  role        user_role not null default 'buyer',
  is_verified boolean not null default false,
  is_suspended boolean not null default false,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table seller_profiles (
  id                  uuid primary key default gen_random_uuid(),
  user_id             uuid not null unique references profiles(id) on delete cascade,
  store_name          text not null,
  store_description   text,
  store_logo          text,
  store_cover         text,
  phone               text,
  whatsapp            text,
  email               text,
  country             text,
  city                text,
  address             text,
  latitude            double precision check (latitude  between -90  and 90),
  longitude           double precision check (longitude between -180 and 180),
  verification_status verification_state not null default 'unverified',
  verified_at         timestamptz,
  rating              numeric(3,2) not null default 0 check (rating between 0 and 5),
  review_count        integer not null default 0,
  total_sales         integer not null default 0,
  can_sell_ebooks     boolean not null default false,   -- admin-granted
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);

create table bookstores (
  id            uuid primary key default gen_random_uuid(),
  seller_id     uuid references seller_profiles(id) on delete set null, -- null until claimed
  store_name    text not null,
  address       text,
  city          text,
  region        text,
  country       text,
  latitude      double precision check (latitude  between -90  and 90),
  longitude     double precision check (longitude between -180 and 180),
  phone         text,
  whatsapp      text,
  opening_hours jsonb,   -- {"mon":{"open":"08:00","close":"18:00"}, ...}
  website       text,
  description   text,
  logo_url      text,
  verified      boolean not null default false,
  created_at    timestamptz not null default now()
);

create table store_claims (
  id          uuid primary key default gen_random_uuid(),
  bookstore_id uuid not null references bookstores(id) on delete cascade,
  claimant_id uuid not null references profiles(id) on delete cascade,
  evidence_url text,
  notes       text,
  status      verification_state not null default 'pending',
  created_at  timestamptz not null default now(),
  reviewed_at timestamptz,
  unique (bookstore_id, claimant_id)
);

create table books (
  id               uuid primary key default gen_random_uuid(),
  title            text not null,
  subtitle         text,
  author           text not null,
  isbn_10          text,
  isbn_13          text,
  description      text,
  publisher        text,
  publication_date date,
  language         text default 'en',
  category_id      uuid references categories(id) on delete set null,
  cover_image_url  text,
  book_type        book_type not null default 'physical',
  external_source  text,            -- 'google_books' | 'open_library'
  external_id      text,
  review_status    text not null default 'approved' check (review_status in ('pending','approved','rejected')),
  created_by       uuid references profiles(id) on delete set null,
  search_vector    tsvector generated always as (
                     to_tsvector('simple',
                       coalesce(title,'')||' '||coalesce(subtitle,'')||' '||coalesce(author,'')||' '||coalesce(publisher,''))
                   ) stored,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now(),
  unique (external_source, external_id)
);

create table book_editions (
  id              uuid primary key default gen_random_uuid(),
  book_id         uuid not null references books(id) on delete cascade,
  edition_name    text,
  edition_year    integer check (edition_year between 1400 and 2200),
  format          edition_format not null default 'Paperback',
  isbn            text,
  publisher       text,
  page_count      integer check (page_count > 0),
  language        text,
  cover_image_url text,
  created_at      timestamptz not null default now()
);

create table listings (
  id                  uuid primary key default gen_random_uuid(),
  seller_id           uuid not null references seller_profiles(id) on delete cascade,
  book_id             uuid not null references books(id) on delete restrict,
  edition_id          uuid references book_editions(id) on delete restrict,
  title               text not null,
  description         text,
  price               numeric(12,2) not null check (price >= 0),
  currency            char(3) not null default 'GHS',
  condition           book_condition not null default 'New',
  stock_quantity      integer not null default 1 check (stock_quantity >= 0),
  images              text[] not null default '{}',
  delivery_available  boolean not null default true,
  pickup_available    boolean not null default false,
  delivery_days       integer check (delivery_days >= 0),
  ebook_available     boolean not null default false,
  ebook_file_path     text,            -- PRIVATE storage path (never a public URL)
  ebook_rights_basis  ebook_rights,
  ebook_rights_declared boolean not null default false,
  is_featured         boolean not null default false,
  status              listing_status not null default 'draft',
  rejection_reason    text,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now(),
  constraint ebook_requires_rights check (
    ebook_available = false or
    (ebook_rights_declared = true and ebook_rights_basis is not null and ebook_file_path is not null)
  )
);

create table carts (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null unique references profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table cart_items (
  id            uuid primary key default gen_random_uuid(),
  cart_id       uuid not null references carts(id) on delete cascade,
  listing_id    uuid not null references listings(id) on delete cascade,
  quantity      integer not null default 1 check (quantity > 0),
  price_at_time numeric(12,2) not null,
  created_at    timestamptz not null default now(),
  unique (cart_id, listing_id)
);

create table addresses (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references profiles(id) on delete cascade,
  full_name  text not null,
  phone      text not null,
  country    text not null,
  city       text not null,
  region     text,
  address    text not null,
  latitude   double precision,
  longitude  double precision,
  is_default boolean not null default false,
  created_at timestamptz not null default now()
);
create unique index one_default_address on addresses(user_id) where is_default;

create table orders (
  id                  uuid primary key default gen_random_uuid(),
  buyer_id            uuid not null references profiles(id) on delete restrict,
  total_amount        numeric(12,2) not null check (total_amount >= 0),
  currency            char(3) not null default 'GHS',
  delivery_fee        numeric(12,2) not null default 0,
  platform_fee        numeric(12,2) not null default 0,
  payment_status      payment_status not null default 'pending',
  order_status        order_status not null default 'pending_payment',
  shipping_address    jsonb,           -- snapshot at time of order
  tracking_number     text,
  has_ebook           boolean not null default false,
  delivered_at        timestamptz,
  buyer_confirmed_at  timestamptz,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);

create table order_items (
  id         uuid primary key default gen_random_uuid(),
  order_id   uuid not null references orders(id) on delete cascade,
  listing_id uuid not null references listings(id) on delete restrict,
  seller_id  uuid not null references seller_profiles(id) on delete restrict,
  quantity   integer not null check (quantity > 0),
  unit_price numeric(12,2) not null,
  subtotal   numeric(12,2) not null,
  is_ebook   boolean not null default false,
  created_at timestamptz not null default now()
);

create table payments (
  id                      uuid primary key default gen_random_uuid(),
  order_id                uuid not null references orders(id) on delete restrict,
  buyer_id                uuid not null references profiles(id) on delete restrict,
  provider                text not null,                 -- 'paystack' | 'hubtel' | 'flutterwave' ...
  provider_transaction_id text,
  amount                  numeric(12,2) not null,
  currency                char(3) not null,
  payment_method          text,                          -- 'momo_mtn','card',... NEVER raw card data
  status                  payment_status not null default 'pending',
  paid_at                 timestamptz,
  created_at              timestamptz not null default now(),
  unique (provider, provider_transaction_id)
);

create table seller_payouts (
  id                 uuid primary key default gen_random_uuid(),
  seller_id          uuid not null references seller_profiles(id) on delete restrict,
  order_id           uuid references orders(id) on delete restrict,
  amount             numeric(12,2) not null check (amount >= 0),
  currency           char(3) not null default 'GHS',
  payout_status      payout_status not null default 'pending',
  provider_reference text,
  requested_at       timestamptz not null default now(),
  paid_at            timestamptz
);

create table conversations (
  id         uuid primary key default gen_random_uuid(),
  buyer_id   uuid not null references profiles(id) on delete cascade,   -- user ids (not seller_profiles)
  seller_id  uuid not null references profiles(id) on delete cascade,
  listing_id uuid references listings(id) on delete set null,
  order_id   uuid references orders(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (buyer_id <> seller_id)
);
create unique index one_conv_per_listing on conversations(buyer_id, seller_id, coalesce(listing_id, '00000000-0000-0000-0000-000000000000'::uuid));

create table messages (
  id              uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references conversations(id) on delete cascade,
  sender_id       uuid not null references profiles(id) on delete cascade,
  receiver_id     uuid not null references profiles(id) on delete cascade,
  listing_id      uuid references listings(id) on delete set null,
  order_id        uuid references orders(id) on delete set null,
  message         text,
  attachment_url  text,
  is_read         boolean not null default false,
  created_at      timestamptz not null default now(),
  check (message is not null or attachment_url is not null)
);

create table reviews (
  id          uuid primary key default gen_random_uuid(),
  reviewer_id uuid not null references profiles(id) on delete cascade,
  seller_id   uuid not null references seller_profiles(id) on delete cascade,
  listing_id  uuid references listings(id) on delete set null,
  order_id    uuid not null references orders(id) on delete cascade,
  rating      smallint not null check (rating between 1 and 5),
  comment     text,
  is_hidden   boolean not null default false,
  created_at  timestamptz not null default now(),
  unique (reviewer_id, order_id, seller_id)
);

create table wishlists (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references profiles(id) on delete cascade,
  listing_id uuid not null references listings(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (user_id, listing_id)
);

create table notifications (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references profiles(id) on delete cascade,
  type       text not null,
  title      text not null,
  message    text,
  link       text,
  is_read    boolean not null default false,
  created_at timestamptz not null default now()
);

create table disputes (
  id                    uuid primary key default gen_random_uuid(),
  order_id              uuid not null references orders(id) on delete cascade,
  buyer_id              uuid not null references profiles(id) on delete cascade,
  seller_id             uuid not null references seller_profiles(id) on delete cascade,
  reason                text not null,
  description           text,
  evidence_url          text,
  status                dispute_status not null default 'open',
  previous_order_status order_status,
  admin_notes           text,
  created_at            timestamptz not null default now(),
  resolved_at           timestamptz
);

create table reports (
  id               uuid primary key default gen_random_uuid(),
  reporter_id      uuid not null references profiles(id) on delete cascade,
  reported_user_id uuid references profiles(id) on delete cascade,
  listing_id       uuid references listings(id) on delete cascade,
  reason           text not null,
  description      text,
  status           report_status not null default 'open',
  created_at       timestamptz not null default now(),
  check (reported_user_id is not null or listing_id is not null)
);

-- My Library: written ONLY by mark_payment_succeeded()
create table ebook_purchases (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references profiles(id) on delete cascade,
  listing_id  uuid not null references listings(id) on delete restrict,
  order_id    uuid not null references orders(id) on delete restrict,
  access_status text not null default 'active' check (access_status in ('active','revoked')),
  created_at  timestamptz not null default now(),
  unique (user_id, listing_id)
);

-- ---------------------------------------------------------------------
-- 3. INDEXES
-- ---------------------------------------------------------------------
create index idx_profiles_role        on profiles(role);
create index idx_seller_user          on seller_profiles(user_id);
create index idx_seller_verif         on seller_profiles(verification_status);
create index idx_seller_geo           on seller_profiles(latitude, longitude);
create index idx_seller_country_city  on seller_profiles(country, city);
create index idx_seller_name_trgm     on seller_profiles using gin (store_name gin_trgm_ops);
create index idx_store_geo            on bookstores(latitude, longitude);
create index idx_store_name_trgm      on bookstores using gin (store_name gin_trgm_ops);
create index idx_cat_parent           on categories(parent_category_id);
create index idx_books_isbn10         on books(isbn_10);
create index idx_books_isbn13         on books(isbn_13);
create index idx_books_category       on books(category_id);
create index idx_books_fts            on books using gin (search_vector);
create index idx_books_title_trgm     on books using gin (title gin_trgm_ops);
create index idx_books_author_trgm    on books using gin (author gin_trgm_ops);
create index idx_editions_book        on book_editions(book_id);
create index idx_editions_isbn        on book_editions(isbn);
create index idx_listings_seller      on listings(seller_id);
create index idx_listings_book        on listings(book_id);
create index idx_listings_edition     on listings(edition_id);
create index idx_listings_status      on listings(status);
create index idx_listings_price       on listings(price);
create index idx_listings_active_edition on listings(edition_id, price) where status = 'active';
create index idx_listings_featured    on listings(is_featured) where is_featured and status = 'active';
create index idx_listings_created     on listings(created_at desc);
create index idx_cart_items_cart      on cart_items(cart_id);
create index idx_orders_buyer         on orders(buyer_id, created_at desc);
create index idx_orders_status        on orders(order_status);
create index idx_order_items_order    on order_items(order_id);
create index idx_order_items_seller   on order_items(seller_id);
create index idx_payments_order       on payments(order_id);
create index idx_payouts_seller       on seller_payouts(seller_id, payout_status);
create index idx_messages_conv        on messages(conversation_id, created_at);
create index idx_messages_receiver    on messages(receiver_id) where not is_read;
create index idx_conv_buyer           on conversations(buyer_id);
create index idx_conv_seller          on conversations(seller_id);
create index idx_reviews_seller       on reviews(seller_id);
create index idx_notif_user           on notifications(user_id, is_read, created_at desc);
create index idx_disputes_status      on disputes(status);
create index idx_reports_status       on reports(status);
create index idx_addresses_user       on addresses(user_id);
create index idx_wishlist_user        on wishlists(user_id);
create index idx_ebook_user           on ebook_purchases(user_id);

-- ---------------------------------------------------------------------
-- 4. HELPER FUNCTIONS (SECURITY DEFINER avoids RLS recursion)
-- ---------------------------------------------------------------------
create or replace function set_updated_at() returns trigger
language plpgsql as $$ begin new.updated_at = now(); return new; end $$;

create or replace function is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and role = 'admin' and not is_suspended);
$$;

create or replace function my_seller_id() returns uuid
language sql stable security definer set search_path = public as $$
  select id from seller_profiles where user_id = auth.uid();
$$;

create or replace function is_order_buyer(oid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from orders where id = oid and buyer_id = auth.uid());
$$;

create or replace function is_order_seller(oid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from order_items oi join seller_profiles sp on sp.id = oi.seller_id
                 where oi.order_id = oid and sp.user_id = auth.uid());
$$;

create or replace function is_conversation_member(cid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from conversations where id = cid and auth.uid() in (buyer_id, seller_id));
$$;

create or replace function has_verified_purchase(oid uuid, sid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from orders o join order_items oi on oi.order_id = o.id
    where o.id = oid and o.buyer_id = auth.uid() and oi.seller_id = sid
      and o.order_status in ('delivered','buyer_confirmed','completed'));
$$;

-- For your Edge Function (service role) that mints signed ebook URLs
create or replace function has_ebook_access(p_user uuid, p_listing uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from ebook_purchases
                 where user_id = p_user and listing_id = p_listing and access_status = 'active');
$$;
revoke all on function has_ebook_access(uuid, uuid) from public, anon, authenticated;

create or replace function haversine_km(lat1 float8, lon1 float8, lat2 float8, lon2 float8) returns float8
language sql immutable as $$
  select 6371 * 2 * asin(sqrt(
    power(sin(radians(lat2 - lat1) / 2), 2) +
    cos(radians(lat1)) * cos(radians(lat2)) * power(sin(radians(lon2 - lon1) / 2), 2)));
$$;

-- ---------------------------------------------------------------------
-- 5. TRIGGERS
-- ---------------------------------------------------------------------
-- updated_at
do $$ declare t text; begin
  foreach t in array array['profiles','seller_profiles','books','listings','carts','orders','conversations'] loop
    execute format('create trigger trg_%1$s_updated before update on %1$s for each row execute function set_updated_at()', t);
  end loop;
end $$;

-- New auth user -> profile + cart. Admin role can NEVER be set from signup metadata.
create or replace function handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare purpose text := lower(coalesce(new.raw_user_meta_data->>'account_purpose','buyer'));
begin
  insert into profiles (id, full_name, email, phone, country, city, role)
  values (new.id,
          coalesce(new.raw_user_meta_data->>'full_name',''),
          new.email,
          new.raw_user_meta_data->>'phone',
          new.raw_user_meta_data->>'country',
          new.raw_user_meta_data->>'city',
          case purpose when 'seller' then 'seller'::user_role when 'both' then 'both'::user_role else 'buyer'::user_role end);
  insert into carts (user_id) values (new.id);
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();

-- Mirror email verification
create or replace function sync_email_verified() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  update profiles set is_verified = (new.email_confirmed_at is not null), email = new.email where id = new.id;
  return new;
end $$;
create trigger on_auth_user_updated after update of email_confirmed_at, email on auth.users
  for each row execute function sync_email_verified();

-- Block privilege escalation on profiles
create or replace function guard_profile() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or is_admin() then return new; end if;   -- service role / admin
  if new.role = 'admin' and old.role <> 'admin' then raise exception 'cannot self-assign admin'; end if;
  if old.role = 'admin' and new.role <> 'admin'  then raise exception 'cannot change admin role'; end if;
  if new.is_verified is distinct from old.is_verified or new.is_suspended is distinct from old.is_suspended
     then raise exception 'protected field'; end if;
  return new;
end $$;
create trigger trg_guard_profile before update on profiles for each row execute function guard_profile();

-- Block self-verification on seller profiles
create or replace function guard_seller_profile() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or is_admin() then return new; end if;
  if tg_op = 'INSERT' then
    new.verification_status := 'unverified'; new.verified_at := null; new.rating := 0;
    new.total_sales := 0; new.review_count := 0; new.can_sell_ebooks := false;
  else
    if new.verification_status is distinct from old.verification_status
       and not (old.verification_status = 'unverified' and new.verification_status = 'pending')
       then raise exception 'verification is admin-only'; end if;
    new.verified_at := old.verified_at; new.rating := old.rating; new.total_sales := old.total_sales;
    new.review_count := old.review_count; new.can_sell_ebooks := old.can_sell_ebooks;
  end if;
  return new;
end $$;
create trigger trg_guard_seller before insert or update on seller_profiles
  for each row execute function guard_seller_profile();

-- Listing rules: sellers can't self-approve ebooks / admin-rejected content; need rights + permission
create or replace function guard_listing() returns trigger
language plpgsql security definer set search_path = public as $$
declare can_ebook boolean;
begin
  if auth.uid() is null or is_admin() then return new; end if;
  new.is_featured := case when tg_op = 'INSERT' then false else old.is_featured end;
  if tg_op = 'UPDATE' and old.status in ('rejected','removed') and new.status <> old.status then
    raise exception 'listing locked by moderation';
  end if;
  if new.ebook_available then
    select can_sell_ebooks into can_ebook from seller_profiles where id = new.seller_id;
    if not coalesce(can_ebook,false) then raise exception 'seller not authorized for ebooks'; end if;
    if new.status = 'active' and (tg_op = 'INSERT' or old.status <> 'active') then
      new.status := 'pending_review';   -- ebooks always need admin approval
    end if;
  end if;
  return new;
end $$;
create trigger trg_guard_listing before insert or update on listings
  for each row execute function guard_listing();

-- Dispute opens -> freeze order & hold payouts
create or replace function on_dispute_opened() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  select order_status into new.previous_order_status from orders where id = new.order_id;
  update orders set order_status = 'disputed' where id = new.order_id;
  update seller_payouts set payout_status = 'on_hold'
    where order_id = new.order_id and payout_status in ('pending','processing');
  return new;
end $$;
create trigger trg_dispute_open before insert on disputes for each row execute function on_dispute_opened();

-- Keep seller rating current
create or replace function refresh_seller_rating() returns trigger
language plpgsql security definer set search_path = public as $$
declare sid uuid := coalesce(new.seller_id, old.seller_id);
begin
  update seller_profiles set
    rating = coalesce((select round(avg(rating)::numeric, 2) from reviews where seller_id = sid and not is_hidden), 0),
    review_count = (select count(*) from reviews where seller_id = sid and not is_hidden)
  where id = sid;
  return null;
end $$;
create trigger trg_review_rating after insert or update or delete on reviews
  for each row execute function refresh_seller_rating();

-- Bump conversation on new message
create or replace function touch_conversation() returns trigger
language plpgsql security definer set search_path = public as $$
begin update conversations set updated_at = now() where id = new.conversation_id; return new; end $$;
create trigger trg_msg_touch after insert on messages for each row execute function touch_conversation();

-- Notify receiver of new message
create or replace function notify_message() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into notifications (user_id, type, title, message, link)
  values (new.receiver_id, 'message', 'New message', left(coalesce(new.message,'Sent an attachment'), 120),
          '/messages/' || new.conversation_id);
  return new;
end $$;
create trigger trg_msg_notify after insert on messages for each row execute function notify_message();

-- ---------------------------------------------------------------------
-- 6. PUBLIC VIEW (hides phone/email so users never have to reveal contact details)
-- ---------------------------------------------------------------------
create view seller_public as
  select id, user_id, store_name, store_description, store_logo, store_cover, country, city,
         latitude, longitude, verification_status, rating, review_count, total_sales, created_at
  from seller_profiles
  where verification_status <> 'suspended';
grant select on seller_public to anon, authenticated;

-- ---------------------------------------------------------------------
-- 7. BUSINESS RPCs
-- ---------------------------------------------------------------------
-- 7a. Paginated, filterable search (never load the whole catalog client-side)
create or replace function search_listings(
  q text default null, p_category uuid default null,
  p_min_price numeric default null, p_max_price numeric default null,
  p_condition book_condition default null, p_format edition_format default null,
  p_ebook boolean default null, p_country text default null, p_min_rating numeric default null,
  p_lat float8 default null, p_lng float8 default null, p_max_km float8 default null,
  p_sort text default 'relevance',   -- relevance | price_asc | rating | nearest | newest | fastest
  p_limit int default 24, p_offset int default 0)
returns table (
  listing_id uuid, book_id uuid, edition_id uuid, title text, author text, cover_image_url text,
  format edition_format, price numeric, currency char(3), condition book_condition,
  stock_quantity int, delivery_days int, ebook_available boolean,
  seller_id uuid, store_name text, seller_rating numeric, seller_verified boolean,
  distance_km float8, created_at timestamptz)
language sql stable security definer set search_path = public as $$
  select * from (
    select l.id, b.id, l.edition_id, b.title, b.author,
           coalesce(l.images[1], e.cover_image_url, b.cover_image_url),
           e.format, l.price, l.currency, l.condition, l.stock_quantity, l.delivery_days, l.ebook_available,
           sp.id, sp.store_name, sp.rating, (sp.verification_status = 'verified'),
           case when p_lat is not null and sp.latitude is not null
                then haversine_km(p_lat, p_lng, sp.latitude, sp.longitude) end as dist,
           l.created_at
    from listings l
    join books b on b.id = l.book_id
    left join book_editions e on e.id = l.edition_id
    join seller_profiles sp on sp.id = l.seller_id
    where l.status = 'active' and l.stock_quantity > 0 and sp.verification_status <> 'suspended'
      and (q is null or q = '' or b.search_vector @@ plainto_tsquery('simple', q)
           or b.title % q or b.author % q or b.isbn_13 = q or b.isbn_10 = q or e.isbn = q
           or sp.store_name ilike '%'||q||'%')
      and (p_category is null or b.category_id = p_category)
      and (p_min_price is null or l.price >= p_min_price)
      and (p_max_price is null or l.price <= p_max_price)
      and (p_condition is null or l.condition = p_condition)
      and (p_format is null or e.format = p_format)
      and (p_ebook is null or l.ebook_available = p_ebook)
      and (p_country is null or sp.country = p_country)
      and (p_min_rating is null or sp.rating >= p_min_rating)
  ) r(listing_id, book_id, edition_id, title, author, cover_image_url, format, price, currency, condition,
      stock_quantity, delivery_days, ebook_available, seller_id, store_name, seller_rating, seller_verified,
      distance_km, created_at)
  where p_max_km is null or distance_km <= p_max_km
  order by
    case when p_sort = 'price_asc' then price end asc,
    case when p_sort = 'rating'    then seller_rating end desc,
    case when p_sort = 'nearest'   then distance_km end asc,
    case when p_sort = 'fastest'   then delivery_days end asc,
    created_at desc
  limit least(p_limit, 100) offset greatest(p_offset, 0);
$$;
grant execute on function search_listings to anon, authenticated;

-- 7b. Compare sellers for one edition ("best" = price + rating + speed blend)
create or replace function compare_offers(p_edition uuid)
returns table (listing_id uuid, seller_id uuid, store_name text, price numeric, currency char(3),
               condition book_condition, delivery_days int, pickup_available boolean,
               seller_rating numeric, seller_verified boolean, best_score numeric)
language sql stable security definer set search_path = public as $$
  select l.id, sp.id, sp.store_name, l.price, l.currency, l.condition, l.delivery_days, l.pickup_available,
         sp.rating, sp.verification_status = 'verified',
         round((sp.rating * 20) - (l.price / nullif(max(l.price) over (), 0) * 40) - coalesce(l.delivery_days,3) * 2, 2)
  from listings l join seller_profiles sp on sp.id = l.seller_id
  where l.edition_id = p_edition and l.status = 'active' and l.stock_quantity > 0
    and sp.verification_status <> 'suspended'
  order by 11 desc;
$$;
grant execute on function compare_offers to anon, authenticated;

-- 7c. Checkout: cart -> order (server-side price check, stock check)
-- Platform fee rate is a placeholder (5%); move to a settings table when finalised.
create or replace function place_order(p_shipping jsonb, p_delivery_fee numeric default 0)
returns uuid language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); oid uuid; sub numeric := 0; cur char(3); r record; any_ebook boolean := false;
begin
  if uid is null then raise exception 'not authenticated'; end if;
  if (select is_suspended from profiles where id = uid) then raise exception 'account suspended'; end if;
  if not exists (select 1 from cart_items ci join carts c on c.id = ci.cart_id where c.user_id = uid)
    then raise exception 'cart is empty'; end if;

  for r in select ci.quantity, l.* from cart_items ci join carts c on c.id = ci.cart_id
           join listings l on l.id = ci.listing_id where c.user_id = uid loop
    if r.status <> 'active' or r.stock_quantity < r.quantity then raise exception 'unavailable: %', r.title; end if;
    if r.seller_id = my_seller_id() then raise exception 'cannot buy your own listing'; end if;
    if cur is not null and cur <> r.currency then raise exception 'mixed currencies in cart'; end if;
    cur := r.currency; sub := sub + r.price * r.quantity;
    any_ebook := any_ebook or r.ebook_available;
  end loop;

  insert into orders (buyer_id, total_amount, currency, delivery_fee, platform_fee, shipping_address, has_ebook)
  values (uid, sub + p_delivery_fee, cur, p_delivery_fee, round(sub * 0.05, 2), p_shipping, any_ebook)
  returning id into oid;

  insert into order_items (order_id, listing_id, seller_id, quantity, unit_price, subtotal, is_ebook)
  select oid, l.id, l.seller_id, ci.quantity, l.price, l.price * ci.quantity, l.ebook_available
  from cart_items ci join carts c on c.id = ci.cart_id join listings l on l.id = ci.listing_id
  where c.user_id = uid;

  delete from cart_items where cart_id = (select id from carts where user_id = uid);
  return oid;
end $$;
grant execute on function place_order to authenticated;

-- 7d. Called ONLY by your payment webhook (service role). Idempotent.
create or replace function mark_payment_succeeded(p_order uuid, p_provider text, p_txn text, p_method text)
returns void language plpgsql security definer set search_path = public as $$
declare o orders; r record;
begin
  select * into o from orders where id = p_order for update;
  if o.payment_status = 'successful' then return; end if;   -- idempotent

  insert into payments (order_id, buyer_id, provider, provider_transaction_id, amount, currency, payment_method, status, paid_at)
  values (o.id, o.buyer_id, p_provider, p_txn, o.total_amount, o.currency, p_method, 'successful', now())
  on conflict (provider, provider_transaction_id) do nothing;

  update orders set payment_status = 'successful', order_status = 'payment_successful' where id = o.id;

  for r in select oi.*, sp.user_id as seller_user from order_items oi
           join seller_profiles sp on sp.id = oi.seller_id where oi.order_id = o.id loop
    update listings set stock_quantity = greatest(stock_quantity - r.quantity, 0),
           status = case when stock_quantity - r.quantity <= 0 and not r.is_ebook then 'sold_out' else status end
      where id = r.listing_id;
    if r.is_ebook then
      insert into ebook_purchases (user_id, listing_id, order_id) values (o.buyer_id, r.listing_id, o.id)
      on conflict do nothing;
    end if;
    insert into notifications (user_id, type, title, message, link)
    values (r.seller_user, 'order', 'New paid order', 'You have a new order to process.', '/seller/orders/' || o.id);
  end loop;
end $$;
revoke all on function mark_payment_succeeded from public, anon, authenticated;
grant execute on function mark_payment_succeeded to service_role;

-- 7e. Seller fulfilment transitions (forward-only)
create or replace function seller_set_order_status(p_order uuid, p_status order_status, p_tracking text default null)
returns void language plpgsql security definer set search_path = public as $$
declare cur order_status;
begin
  if not is_order_seller(p_order) then raise exception 'not your order'; end if;
  select order_status into cur from orders where id = p_order for update;
  if cur = 'disputed' then raise exception 'order is disputed'; end if;
  if not ((cur = 'payment_successful' and p_status = 'seller_processing') or
          (cur = 'seller_processing'  and p_status = 'shipped') or
          (cur = 'shipped'            and p_status = 'out_for_delivery') or
          (cur in ('shipped','out_for_delivery') and p_status = 'delivered'))
    then raise exception 'invalid transition % -> %', cur, p_status; end if;
  update orders set order_status = p_status,
         tracking_number = coalesce(p_tracking, tracking_number),
         delivered_at = case when p_status = 'delivered' then now() else delivered_at end
   where id = p_order;
  insert into notifications (user_id, type, title, message, link)
  select buyer_id, 'order', 'Order update', 'Your order is now: ' || p_status, '/orders/' || id from orders where id = p_order;
end $$;
grant execute on function seller_set_order_status to authenticated;

-- 7f. Buyer confirms receipt (payout eligibility is then handled by your backend/provider rules)
create or replace function buyer_confirm_order(p_order uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not is_order_buyer(p_order) then raise exception 'not your order'; end if;
  update orders set order_status = 'buyer_confirmed', buyer_confirmed_at = now()
   where id = p_order and order_status = 'delivered';
  if not found then raise exception 'order not in delivered state'; end if;
end $$;
grant execute on function buyer_confirm_order to authenticated;

-- ---------------------------------------------------------------------
-- 8. ROW LEVEL SECURITY
-- ---------------------------------------------------------------------
do $$ declare t text; begin
  foreach t in array array['categories','profiles','seller_profiles','bookstores','store_claims','books',
    'book_editions','listings','carts','cart_items','addresses','orders','order_items','payments',
    'seller_payouts','conversations','messages','reviews','wishlists','notifications','disputes',
    'reports','ebook_purchases'] loop
    execute format('alter table %I enable row level security', t);
  end loop;
end $$;

-- categories: public read, admin write
create policy cat_read  on categories for select using (true);
create policy cat_admin on categories for all using (is_admin()) with check (is_admin());

-- profiles
create policy profiles_self_read   on profiles for select using (id = auth.uid() or is_admin());
create policy profiles_self_update on profiles for update using (id = auth.uid() or is_admin())
                                                          with check (id = auth.uid() or is_admin());
-- (public display info comes from seller_public view; no direct public profile reads)

-- seller_profiles (private columns: owner/admin only; public uses seller_public)
create policy sp_owner_read   on seller_profiles for select using (user_id = auth.uid() or is_admin());
create policy sp_owner_insert on seller_profiles for insert with check (user_id = auth.uid());
create policy sp_owner_update on seller_profiles for update using (user_id = auth.uid() or is_admin())
                                                           with check (user_id = auth.uid() or is_admin());
create policy sp_admin_delete on seller_profiles for delete using (is_admin());

-- bookstores: public read; owner/admin write
create policy bs_read   on bookstores for select using (true);
create policy bs_insert on bookstores for insert with check (is_admin() or seller_id = my_seller_id());
create policy bs_update on bookstores for update using (is_admin() or seller_id = my_seller_id())
                                                with check (is_admin() or (seller_id = my_seller_id() and verified = false) or seller_id = my_seller_id());
create policy bs_delete on bookstores for delete using (is_admin());

-- store claims
create policy sc_own_read   on store_claims for select using (claimant_id = auth.uid() or is_admin());
create policy sc_own_insert on store_claims for insert with check (claimant_id = auth.uid() and status = 'pending');
create policy sc_admin_upd  on store_claims for update using (is_admin());

-- books: approved are public; creator sees own pending; admin all
create policy books_read   on books for select
  using (review_status = 'approved' or created_by = auth.uid() or is_admin());
create policy books_insert on books for insert to authenticated
  with check (created_by = auth.uid() and (review_status = 'pending' or is_admin()));
create policy books_update on books for update using (is_admin()) with check (is_admin());
create policy books_delete on books for delete using (is_admin());

create policy ed_read   on book_editions for select using (
  exists (select 1 from books b where b.id = book_id and (b.review_status = 'approved' or b.created_by = auth.uid())) or is_admin());
create policy ed_insert on book_editions for insert to authenticated
  with check (is_admin() or exists (select 1 from books b where b.id = book_id and b.created_by = auth.uid()));
create policy ed_admin  on book_editions for update using (is_admin());
create policy ed_del    on book_editions for delete using (is_admin());

-- listings
create policy list_public_read on listings for select using (
  (status = 'active' and exists (select 1 from seller_profiles sp where sp.id = seller_id and sp.verification_status <> 'suspended'))
  or seller_id = my_seller_id() or is_admin());
create policy list_seller_insert on listings for insert with check (seller_id = my_seller_id() or is_admin());
create policy list_seller_update on listings for update using (seller_id = my_seller_id() or is_admin())
                                                       with check (seller_id = my_seller_id() or is_admin());
create policy list_seller_delete on listings for delete using (seller_id = my_seller_id() or is_admin());

-- cart
create policy cart_own on carts for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy cart_items_own on cart_items for all
  using (exists (select 1 from carts c where c.id = cart_id and c.user_id = auth.uid()))
  with check (exists (select 1 from carts c where c.id = cart_id and c.user_id = auth.uid()));

-- addresses / wishlists / notifications
create policy addr_own on addresses for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy wish_own on wishlists for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy notif_read   on notifications for select using (user_id = auth.uid() or is_admin());
create policy notif_update on notifications for update using (user_id = auth.uid());
create policy notif_delete on notifications for delete using (user_id = auth.uid());
create policy notif_admin_ins on notifications for insert with check (is_admin());

-- orders: NO direct insert/update for users — go through RPCs. Read-only here.
create policy orders_read on orders for select using (buyer_id = auth.uid() or is_order_seller(id) or is_admin());
create policy orders_admin_update on orders for update using (is_admin()) with check (is_admin());
create policy oi_read on order_items for select using (is_order_buyer(order_id) or is_order_seller(order_id) or is_admin());

-- payments: buyer reads own; writes = service role only
create policy pay_read on payments for select using (buyer_id = auth.uid() or is_admin());
create policy pay_admin_update on payments for update using (is_admin());

-- payouts: seller reads own; payout requests via your backend; admin manages
create policy payout_read  on seller_payouts for select using (seller_id = my_seller_id() or is_admin());
create policy payout_admin on seller_payouts for update using (is_admin());

-- messaging
create policy conv_read   on conversations for select using (auth.uid() in (buyer_id, seller_id) or is_admin());
create policy conv_insert on conversations for insert with check (buyer_id = auth.uid());
create policy msg_read    on messages for select using (is_conversation_member(conversation_id) or is_admin());
create policy msg_insert  on messages for insert with check (sender_id = auth.uid() and is_conversation_member(conversation_id));
create policy msg_mark_read on messages for update using (receiver_id = auth.uid()) with check (receiver_id = auth.uid());

-- reviews: public read; only verified purchasers write
create policy rev_read   on reviews for select using (not is_hidden or reviewer_id = auth.uid() or is_admin());
create policy rev_insert on reviews for insert with check (reviewer_id = auth.uid() and has_verified_purchase(order_id, seller_id));
create policy rev_update on reviews for update using (reviewer_id = auth.uid() or is_admin());
create policy rev_delete on reviews for delete using (reviewer_id = auth.uid() or is_admin());

-- disputes
create policy disp_read   on disputes for select using (buyer_id = auth.uid() or seller_id = my_seller_id() or is_admin());
create policy disp_insert on disputes for insert with check (buyer_id = auth.uid() and is_order_buyer(order_id));
create policy disp_admin  on disputes for update using (is_admin());

-- reports
create policy rep_read   on reports for select using (reporter_id = auth.uid() or is_admin());
create policy rep_insert on reports for insert with check (reporter_id = auth.uid());
create policy rep_admin  on reports for update using (is_admin());

-- My Library
create policy lib_read on ebook_purchases for select using (user_id = auth.uid() or is_admin());

-- Realtime for chat + notifications
alter publication supabase_realtime add table messages, notifications;

-- ---------------------------------------------------------------------
-- 9. STORAGE BUCKETS + POLICIES  (convention: <bucket>/<user_id>/<file>)
-- ---------------------------------------------------------------------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types) values
 ('avatars',             'avatars',             true,  2097152,  array['image/jpeg','image/png','image/webp']),
 ('store-media',         'store-media',         true,  5242880,  array['image/jpeg','image/png','image/webp']),
 ('book-covers',         'book-covers',         true,  5242880,  array['image/jpeg','image/png','image/webp']),
 ('listing-images',      'listing-images',      true,  5242880,  array['image/jpeg','image/png','image/webp']),
 ('message-attachments', 'message-attachments', false, 10485760, array['image/jpeg','image/png','image/webp']),
 ('dispute-evidence',    'dispute-evidence',    false, 10485760, array['image/jpeg','image/png','image/webp','application/pdf']),
 ('ebooks',              'ebooks',              false, 104857600, array['application/pdf','application/epub+zip'])
on conflict (id) do nothing;

-- Public-read buckets: anyone reads; owner writes into own folder
do $$ declare b text; begin
  foreach b in array array['avatars','store-media','book-covers','listing-images'] loop
    execute format($f$create policy "%1$s_read" on storage.objects for select using (bucket_id = %2$L)$f$, b, b);
    execute format($f$create policy "%1$s_write" on storage.objects for insert to authenticated
      with check (bucket_id = %2$L and (storage.foldername(name))[1] = auth.uid()::text)$f$, b, b);
    execute format($f$create policy "%1$s_modify" on storage.objects for update to authenticated
      using (bucket_id = %2$L and (storage.foldername(name))[1] = auth.uid()::text)$f$, b, b);
    execute format($f$create policy "%1$s_delete" on storage.objects for delete to authenticated
      using (bucket_id = %2$L and ((storage.foldername(name))[1] = auth.uid()::text or is_admin()))$f$, b, b);
  end loop;
end $$;

-- Private buckets: owner (and admin) only. Buyers get ebooks ONLY via signed URLs from an Edge Function.
do $$ declare b text; begin
  foreach b in array array['message-attachments','dispute-evidence','ebooks'] loop
    execute format($f$create policy "%1$s_owner_rw" on storage.objects for all to authenticated
      using (bucket_id = %2$L and ((storage.foldername(name))[1] = auth.uid()::text or is_admin()))
      with check (bucket_id = %2$L and (storage.foldername(name))[1] = auth.uid()::text)$f$, b, b);
  end loop;
end $$;
-- Message attachments: let the other conversation member read (path: <sender_id>/<conversation_id>/<file>)
create policy "msg_attach_member_read" on storage.objects for select to authenticated using (
  bucket_id = 'message-attachments' and is_conversation_member(((storage.foldername(name))[2])::uuid));
-- Ebook uploads additionally require admin-granted permission
create policy "ebooks_upload_authorized" on storage.objects as restrictive for insert to authenticated with check (
  bucket_id <> 'ebooks' or exists (select 1 from seller_profiles where user_id = auth.uid() and can_sell_ebooks));

-- ---------------------------------------------------------------------
-- 10. SEED (clearly labelled demo categories only — no fake users/orders)
-- ---------------------------------------------------------------------
insert into categories (name, slug) values
 ('Fiction','fiction'),('Business','business'),('Technology','technology'),('Education','education'),
 ('Children''s Books','childrens-books'),('Science','science'),('History','history'),('Geography','geography'),
 ('Religion','religion'),('Health','health'),('Law','law'),('Mathematics','mathematics'),
 ('Manga/Comics','manga-comics'),('Self Development','self-development')
on conflict (slug) do nothing;
insert into categories (name, slug, parent_category_id)
select v.name, v.slug, c.id from (values
  ('Romance','romance','fiction'),('Economics','economics','business'),
  ('Computer Science','computer-science','technology'),('Programming','programming','technology'),
  ('Cybersecurity','cybersecurity','technology')) v(name, slug, parent)
join categories c on c.slug = v.parent
on conflict (slug) do nothing;

-- ---------------------------------------------------------------------
-- 11. SETUP NOTES
-- ---------------------------------------------------------------------
-- AUTH (Dashboard > Authentication): enable Email provider, turn ON "Confirm email",
--   set Site URL + Redirect URLs, enable password reset template.
--   Signup call: supabase.auth.signUp({email, password, options:{data:{full_name, phone, country, city, account_purpose}}})
-- FIRST ADMIN: sign up normally, then in SQL editor run:
--   update profiles set role = 'admin' where email = 'you@example.com';
-- ENV VARS (frontend): NEXT_PUBLIC_SUPABASE_URL, NEXT_PUBLIC_SUPABASE_ANON_KEY
-- ENV VARS (server only, never in browser): SUPABASE_SERVICE_ROLE_KEY, PAYMENT_PROVIDER_SECRET_KEY,
--   PAYMENT_WEBHOOK_SECRET, GOOGLE_BOOKS_API_KEY
-- PAYMENTS: webhook (Edge Function) verifies provider signature, then calls
--   rpc('mark_payment_succeeded') with the service-role client. Wrap the provider behind one interface
--   (createCheckout / verifyWebhook / payout) so it can be swapped.
-- EBOOKS: Edge Function checks has_ebook_access(user, listing), then
--   storage.from('ebooks').createSignedUrl(path, 60) with the service-role client.
-- ESCROW: none implemented. Payout release logic (after buyer_confirmed / no dispute) must follow
--   your licensed provider's marketplace/split-payment rules.
-- KNOWN SIMPLIFICATIONS: multi-seller carts share one order status (split per-seller sub-orders
--   later); platform fee rate is hard-coded at 5%; seller_payouts rows are created by backend, not here.
